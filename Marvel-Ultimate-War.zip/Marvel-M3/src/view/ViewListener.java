package view;

import javafx.scene.Scene;

public interface ViewListener {
void onChangeScene(Scene scene);

}
